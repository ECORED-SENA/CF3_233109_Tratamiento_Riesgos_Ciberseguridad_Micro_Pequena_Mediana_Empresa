function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6J5XhQV3Tos":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

