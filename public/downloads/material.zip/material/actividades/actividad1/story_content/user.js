function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5XE2UzafptS":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

