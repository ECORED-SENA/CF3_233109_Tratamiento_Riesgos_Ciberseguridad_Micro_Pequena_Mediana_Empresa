function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6nchGzSLA3Y":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

